"use strict";

function injectCaption(text) {
    $("#caption").append(text);
}