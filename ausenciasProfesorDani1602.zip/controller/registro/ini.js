"use strict";

let gestor = new Gestor();
let loginManager = new LoginManager();
let registroManager = new RegistroManager();

function changePageIndex(ressult){ window.location.assign("../index.html"); }